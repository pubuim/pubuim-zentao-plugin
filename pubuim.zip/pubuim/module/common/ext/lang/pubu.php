<?php


$lang->menuOrder[] = 'pubu';
$lang->menu->pubu = 'PubuIM 配置|pubu|index';

$lang->pubu = new stdclass();
$lang->pubu->menu = new stdclass();

$lang->pubu->menu->pubu = array('link' => 'PubuIM 配置|pubu|index', 'subModule' => 'pubu');

$lang->pubu->menuOrder[22] = 'pubu';
