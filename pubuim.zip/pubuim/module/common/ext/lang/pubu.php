<?php


$lang->menuOrder[] = 'pubu';
$lang->menu->pubu = '瀑布IM 配置|pubu|index';

$lang->pubu = new stdclass();
$lang->pubu->menu = new stdclass();

$lang->pubu->menu->pubu = array('link' => '瀑布IM 配置|pubu|index', 'subModule' => 'pubu');

$lang->pubu->menuOrder[22] = 'pubu';
