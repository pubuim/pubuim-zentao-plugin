<?php

//权限相关
$lang->pubu->common = 'PubuIM 配置';
$lang->pubu->index  = '首页';
//base
