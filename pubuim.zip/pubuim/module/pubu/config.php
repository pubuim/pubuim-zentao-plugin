<?php

$config->pubu = new stdclass();

$config->pubu->webhook = '';
//http://dev.app.com:3000/messages/550696f90f3f5f027016aa02
//http://www.zentao.net/book/zentaopmshelp/144.html
//http://192.168.99.100:32768/pro/pubu/