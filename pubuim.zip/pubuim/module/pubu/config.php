<?php

$config->pubu = new stdclass();

$config->pubu->webhook = '';